/*------------------------------------------------------------------------------------------------*/
/* MCU specific stub code for OpenAlliance TC6 10BASE-T1S MACPHY via SPI protocol                 */
/* Copyright 2020, Microchip Technology Inc. and its subsidiaries.                                */
/*                                                                                                */
/* Redistribution and use in source and binary forms, with or without                             */
/* modification, are permitted provided that the following conditions are met:                    */
/*                                                                                                */
/* 1. Redistributions of source code must retain the above copyright notice, this                 */
/*    list of conditions and the following disclaimer.                                            */
/*                                                                                                */
/* 2. Redistributions in binary form must reproduce the above copyright notice,                   */
/*    this list of conditions and the following disclaimer in the documentation                   */
/*    and/or other materials provided with the distribution.                                      */
/*                                                                                                */
/* 3. Neither the name of the copyright holder nor the names of its                               */
/*    contributors may be used to endorse or promote products derived from                        */
/*    this software without specific prior written permission.                                    */
/*                                                                                                */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"                    */
/* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE                      */
/* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE                 */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE                   */
/* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL                     */
/* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR                     */
/* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER                     */
/* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,                  */
/* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE                  */
/* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                           */
/*------------------------------------------------------------------------------------------------*/

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "definitions.h"
#include "spi_async_driver.h"
#include "tc6.h"

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                          USER ADJUSTABLE                             */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

#define TC6Stub_SPI_Instance    (0)
#define TC6Stub_CS_Instance     (0)
#define TC6Stub_SPI_Speed_Hz    (12 * 1000 * 1000)
#define FIRST_TC6_INSTANCE      (0)
#define ASSERT(x)               __conditional_software_breakpoint(x)

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                      PRIVATE FUNCTION PROTOTYPES                     */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

extern SYSTICK_OBJECT systick; /* Instanced in plib_systick.c */
static void SpiDriverCB(uint8_t spiInstance, uint8_t csInstance, bool success, const uint8_t *pTxBuf, uint8_t *pRxBuf, uint16_t bufSize, void *tag);

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                         PUBLIC FUNCTIONS                             */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

void TC6Stub_InitializeSpi(uint8_t idx)
{
    if (idx > FIRST_TC6_INSTANCE)
    {
        ASSERT(false);
        return;
    }
    SpiDrvAsync_SetSpiConfig(TC6Stub_SPI_Instance, TC6Stub_CS_Instance, TC6Stub_SPI_Speed_Hz, true, true);
    TC6_RESET_Clear();
    SYSTICK_DelayMs(10);
    TC6_RESET_Set();
    SYSTICK_DelayMs(10);
}

bool TC6_CB_OnSpiTransaction(uint8_t tc6instance, uint8_t *pTx, uint8_t *pRx, uint16_t len, void *pGlobalTag)
{
    SpiDrvAsync_TransferParam_t p;
    if (tc6instance > FIRST_TC6_INSTANCE)
    {
        ASSERT(false);
        return false;
    }
    if (!SpiDrvAsync_TransferReady(TC6Stub_SPI_Instance))
    {
        return false;
    }
    p.pTxBuf = pTx;
    p.pRxBuf = pRx;
    p.tag = NULL;
    p.pCallback = SpiDriverCB;
    p.gpioMask = 0;
    p.bufSize = len;
    p.spiInstance = TC6Stub_SPI_Instance;
    p.csInstance = TC6Stub_CS_Instance;
    p.zeroCopyRx = true;
    p.zeroCopyTx = true;
    if (!SpiDrvAsync_Transfer(&p))
    {
        printf("SpiTransaction failed\r\n");
        return false;
    }
    return true;
}

uint32_t TC6Regs_CB_GetTicksMs(void)
{
    return systick.tickCounter;
}

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                CALLBACK FUNCTIONS FROM SPI DRIVER                    */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static void SpiDriverCB(uint8_t spiInstance, uint8_t csInstance, bool success, const uint8_t *pTxBuf, uint8_t *pRxBuf, uint16_t bufSize, void *tag)
{
    (void) csInstance;
    (void) pTxBuf;
    (void) pRxBuf;
    (void) bufSize;
    TC6_SpiBufferDone(FIRST_TC6_INSTANCE, true);
}