/*------------------------------------------------------------------------------------------------*/
/* lwIP Interface Driver for OpenAlliance TC6 10BASE-T1S MACPHY via SPI protocol                  */
/* Copyright 2020, Microchip Technology Inc. and its subsidiaries.                                */
/*                                                                                                */
/* Redistribution and use in source and binary forms, with or without                             */
/* modification, are permitted provided that the following conditions are met:                    */
/*                                                                                                */
/* 1. Redistributions of source code must retain the above copyright notice, this                 */
/*    list of conditions and the following disclaimer.                                            */
/*                                                                                                */
/* 2. Redistributions in binary form must reproduce the above copyright notice,                   */
/*    this list of conditions and the following disclaimer in the documentation                   */
/*    and/or other materials provided with the distribution.                                      */
/*                                                                                                */
/* 3. Neither the name of the copyright holder nor the names of its                               */
/*    contributors may be used to endorse or promote products derived from                        */
/*    this software without specific prior written permission.                                    */
/*                                                                                                */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"                    */
/* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE                      */
/* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE                 */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE                   */
/* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL                     */
/* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR                     */
/* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER                     */
/* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,                  */
/* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE                  */
/* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                           */
/*------------------------------------------------------------------------------------------------*/

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include "netif/etharp.h"
#include "lwip/opt.h"
#include "lwip/stats.h"
#include "tc6.h"
#include "tc6-lwip.h"
#include "peripheral/systick/plib_systick.h"
#include "OLED128x64.h"
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                          USER ADJUSTABLE                             */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

#define LWIP_TC6_MAGIC          (0x47392741)
#define FIRST_TC6_INSTANCE      (0)
#define STATUS0_REGISTER_ADDR   (2)
#define PRINT(...)              printf(__VA_ARGS__)
#define ASSERT(x)

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                      DEFINES AND LOCAL VARIABLES                     */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

typedef struct
{
    struct netif netint;
    struct pbuf *pbuf;
    TC6_t *pTC6;
    char ipAddr[16];
    uint8_t mac[6];
    uint32_t magic;
    uint16_t rxLen;
    bool rxInvalid;
} TC6LwIP_t;

static TC6LwIP_t m;
extern SYSTICK_OBJECT systick; /* Instanced in plib_systick.c */
extern uint8_t StringBuffer[100];
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                  CALLBACK FUNCTIONS FROM TCP/IP STACK                */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static err_t lwIpInit(struct netif *netif);
static err_t lwIpOut(struct netif *netif, struct pbuf *p);
static void OnRawTx(TC6_t *pInst, const uint8_t *pTx, uint16_t len, void *pTag, void *pGlobalTag);

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                              MACROS                                  */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

#define PrintRateLimited(idx, timeout, name, value)                                 \
do {                                                                                \
    static uint32_t cnt_ = 0;                                                       \
    static uint32_t t0_;                                                            \
    uint32_t now = systick.tickCounter;                                             \
    if (cnt_ > 0 && (uint32_t)(now - t0_) < (uint32_t)(timeout)) {                  \
        ++cnt_;                                                                     \
    } else {                                                                        \
        t0_ = now;                                                                  \
        if (cnt_ <= 1) {                                                            \
            PRINT("%08lu: %s: 0x%08lX\r\n",                                           \
                    t0_, (name), ((uint32_t)value));                                \
        } else {                                                                    \
            PRINT("%08lu: %s: 0x%08lX [skipped %lu]\r\n",                             \
                    t0_, (name), ((uint32_t)value), cnt_ - 1);                      \
        }                                                                           \
        cnt_ = 1;                                                                   \
    }                                                                               \
} while(0)

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                         PUBLIC FUNCTIONS                             */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

bool TC6LwIP_Init(const uint8_t ip[4], const uint8_t mac[6], TC6_t *pTC6)
{
    struct ip_addr ipAddr;
    struct ip_addr nm;
    struct ip_addr gw;
    if (!ip || !mac)
    {
        return false;
    }
    memset(&m, 0, sizeof (m));
    m.magic = LWIP_TC6_MAGIC;
    m.pTC6 = pTC6;
    snprintf(m.ipAddr, sizeof (m.ipAddr), "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]);
    memcpy(m.mac, mac, NETIF_MAX_HWADDR_LEN);
    /* Setup lwIP interface */
#if (TC6LwIP_DHCP)
    ip_addr_set_zero(&ip);
    ip_addr_set_zero(&nm);
    ip_addr_set_zero(&gw);
    PRINT("LwIP-Init [MAC=%02X:%02X:%02X:%02X:%02X:%02X, DHCP]\r\n", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
#else
    ipaddr_aton(m.ipAddr, &ipAddr);
    ipaddr_aton(TC6LwIP_NETMASK, &nm);
    ipaddr_aton(TC6LwIP_GATEWAY, &gw);
    PRINT(">> IP = %s\r\n", m.ipAddr);
    sprintf((char *) StringBuffer, ">> IP = %s", m.ipAddr);
    OLED_Put6x8Str(0, 1, (char*) StringBuffer);
    PRINT(">> MAC = %02X:%02X:%02X:%02X:%02X:%02X\r\n", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
#endif
    if (!netif_add(&m.netint, &ipAddr, &nm, &gw, &m, lwIpInit, ethernet_input))
    {
        ASSERT(false);
        PRINT("Could not add TC6 interface to lwIP!\r\n");
        return false;
    }
    return true;
}

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                  CALLBACK FUNCTIONS FROM TCP/IP STACK                */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static err_t lwIpInit(struct netif *netif)
{
    ASSERT(netif && netif == &m.netint);
    ASSERT(LWIP_TC6_MAGIC == ((TC6LwIP_t*) netif->state)->magic);
    netif->output = etharp_output;
    netif->linkoutput = lwIpOut;
    netif->flags = NETIF_FLAG_BROADCAST | NETIF_FLAG_ETHARP | NETIF_FLAG_ETHERNET;
    netif->mtu = TC6LwIP_MTU;
    netif->hwaddr_len = ETHARP_HWADDR_LEN;
    memcpy(netif->name, TC6LwIP_HOSTNAME, 2);
    memcpy(netif->hwaddr, m.mac, NETIF_MAX_HWADDR_LEN);
    netif_set_up(netif);
    netif_set_default(netif);
    return ERR_OK;
}

static err_t lwIpOut(struct netif *netif, struct pbuf *p)
{
    bool success;
    ASSERT(netif && p);
    ASSERT(LWIP_TC6_MAGIC == ((TC6LwIP_t*) netif->state)->magic);
    if (p->tot_len != p->len)
    {
        struct pbuf *pOld = p;
        struct pbuf *pNew;
        uint16_t pos = 0;
        pNew = pbuf_alloc(PBUF_RAW, p->tot_len, PBUF_RAM);
        pNew->tot_len = pNew->len = p->tot_len;
        if (NULL == pNew)
        {
            LINK_STATS_INC(link.memerr);
            LINK_STATS_INC(link.drop);
            PRINT("Failed to reallocate fragmented TX buffer");
            ASSERT(p->ref);
            pbuf_free(p);
            return ERR_MEM;
        }
#if ETH_PAD_SIZE
        pbuf_header(p, -ETH_PAD_SIZE);
#endif
        while (pOld)
        {
            memcpy(pNew->payload + pos, pOld->payload, pOld->len);
            pos += pOld->len;
            pOld = pOld->next;
        }
#if ETH_PAD_SIZE
        pbuf_header(p, ETH_PAD_SIZE);
#endif
        ASSERT(pos == p->tot_len);
        ASSERT(p->ref);
        pbuf_free(p);
        p = pNew;
    }
    else
    {
        pbuf_ref(p);
    }
    ASSERT(p->tot_len == p->len);
    ASSERT(p->ref);
    success = TC6_SendRawEthernetPacket(m.pTC6, p->payload, p->tot_len, 0, OnRawTx, p);
    return success ? ERR_OK : ERR_WOULDBLOCK;
}

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                  CALLBACK FUNCTIONS FROM TC6 STACK               */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static void OnRawTx(TC6_t *pInst, const uint8_t *pTx, uint16_t len, void *pTag, void *pGlobalTag)
{
    struct pbuf *p = pTag;
    ASSERT(m.pTC6 == pInst);
    ASSERT(pTx == p->payload);
    ASSERT(len == p->tot_len);
    ASSERT(len == p->len);
    ASSERT(p->ref);
    pbuf_free(p);
}

void TC6_CB_OnRxEthernetSlice(TC6_t *pInst, const uint8_t *pRx, uint16_t offset, uint16_t len, void *pGlobalTag)
{
    ASSERT(m.pTC6 == pInst);
    if (m.rxInvalid)
    {
        PRINT("on_rx_slice: ignoring invalid marked. offset=%d", offset);
        return;
    }
    if (offset + len > TC6LwIP_MTU)
    {
        PRINT("on_rx_slice:packet greater than MTU=%d", (offset + len));
        m.rxInvalid = true;
        return;
    }
    if (offset)
    {
        if (!m.pbuf || !m.rxLen)
        {
            ASSERT(false);
            m.rxInvalid = true;
            return;
        }
    }
    else
    {
        if (m.pbuf || m.rxLen)
        {
            ASSERT(false);
            m.rxInvalid = true;
            return;
        }
        m.pbuf = pbuf_alloc(PBUF_RAW, TC6LwIP_MTU, PBUF_RAM);
        if (!m.pbuf)
        {
            PRINT("rx_slice: could not allocate memory. len=%d", TC6LwIP_MTU);
            m.rxInvalid = true;
            return;
        }
        ASSERT(m.pbuf->ref != 0);
        if (m.pbuf->next)
        {
            PRINT("rx_slice: could not allocate unsegmented memory diff=%d", (m.pbuf->tot_len - m.pbuf->len));
            m.rxInvalid = true;
            pbuf_free(m.pbuf);
            m.pbuf = NULL;
            return;
        }
    }
    memcpy(m.pbuf->payload + offset, pRx, len);
    m.rxLen += len;
}

void TC6_CB_OnRxEthernetPacket(TC6_t *pInst, bool success, uint16_t len, uint64_t *rxTimestamp, void *pGlobalTag)
{
#define MIN_HEADER_LEN  (42)
    uint16_t ethType;
    struct eth_hdr *ethhdr;
    ASSERT(m.pTC6 == pInst);
    if (!success || m.rxInvalid || !m.pbuf || !m.rxLen)
    {
        PRINT("on_rx_eth_ready: packet drop");
        goto free;
    }
    if (m.rxLen != len)
    {
        PRINT("on_rx_eth_ready: size mismatch");
        goto free;
    }
    if (len < MIN_HEADER_LEN)
    {
        PRINT("on_rx_eth_ready: received invalid small packet len=%d", len);
        goto free;
    }
    ASSERT(m.pbuf);
    ASSERT(m.pbuf->ref != 0);
    pbuf_realloc(m.pbuf, len);
    ethhdr = m.pbuf->payload;
    ethType = htons(ethhdr->type);
    if (TC6LwIP_CB_OnRxEthernetPacket(m.pbuf, ethType))
    {
        err_t result = m.netint.input(m.pbuf, &m.netint);
        if (ERR_OK == result)
        {
            m.pbuf = NULL;
            m.rxLen = 0;
            m.rxInvalid = false;
            return;
        }
        else
        {
            PRINT("on_rx_eth_ready: IP input error=%d", result);
            goto free;
        }
    }
free:
    if (m.pbuf)
    {
        ASSERT(m.pbuf != 0);
        pbuf_free(m.pbuf);
        m.pbuf = NULL;
    }
    m.rxLen = 0;
    m.rxInvalid = false;
}