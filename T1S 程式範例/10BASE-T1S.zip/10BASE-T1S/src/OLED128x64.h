#ifndef OLED_128x64_H
#define	OLED_128x64_H

#include <xc.h>

#define OLED_ADDRESS            0x3C
#define X_WIDTH                 128
#define Y_WIDTH                 64
#define OLED_Command_Mode       0x80
#define OLED_Data_Mode		    0xC0

void OLED_Write_Command(uint8_t Command);
void OLED_Write_Data(uint8_t Data);
void OLED_Init(void);
void Display_On(void);
void Display_Off(void);
void OLED_Clear(void);
void OLED_SetCursor(uint8_t x, uint8_t y);
void OLED_Put6x8Str(uint8_t x, uint8_t y, char ch[]);
void OLED_Put6x8ASCII(uint8_t x, uint8_t y, char data[]);
void OLED_Put8x16Str(uint8_t x, uint8_t y, char ch[]);
void OLED_Put8x16ASCII(uint8_t x, uint8_t y, char data[]);
#endif

