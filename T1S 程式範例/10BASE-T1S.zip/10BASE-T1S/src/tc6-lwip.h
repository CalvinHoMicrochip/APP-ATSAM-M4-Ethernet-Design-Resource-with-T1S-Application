/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */
#ifndef TC6_LWIP_H_
#define TC6_LWIP_H_

#include <stdint.h>
#include <stdbool.h>
#include "lwip/pbuf.h"
#include "tc6.h"

#ifdef __cplusplus
extern "C" {
#endif

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                          USER ADJUSTABLE                             */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

#define TC6LwIP_MTU                 (1536)
#define TC6LwIP_HOSTNAME            (char *)"tc6"
#define TC6LwIP_DHCP                (false)
#define TC6LwIP_NETMASK             "255.255.255.0"
#define TC6LwIP_GATEWAY             "192.168.0.1"

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                            PUBLIC API                                */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

bool TC6LwIP_Init(const uint8_t ip[4], const uint8_t mac[6], TC6_t *pTC6);

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                        CALLBACK SECTION                              */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

extern bool TC6LwIP_CB_OnRxEthernetPacket(struct pbuf *pRx, uint16_t ethType);

#ifdef __cplusplus
}
#endif
#endif /* TC6_LWIP_H_ */
