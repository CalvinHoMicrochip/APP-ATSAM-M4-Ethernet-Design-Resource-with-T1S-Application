#include "xc.h"
#include "OLED128x64.h"
#include "OLED_Font.h"
#include "config/default/peripheral/sercom/i2c_master/plib_sercom1_i2c_master.h"
#include <string.h>

uint8_t TxBuffer[20];

void OLED_Write_Command(uint8_t Command)
{
    TxBuffer[0] = OLED_Command_Mode;
    TxBuffer[1] = Command;
    SERCOM1_I2C_Write(OLED_ADDRESS, TxBuffer, 2);
    while (SERCOM1_I2C_IsBusy());
}

void OLED_Write_Data(uint8_t Data)
{
    TxBuffer[0] = OLED_Data_Mode;
    TxBuffer[1] = Data;
    SERCOM1_I2C_Write(OLED_ADDRESS, TxBuffer, 2);
    while (SERCOM1_I2C_IsBusy());
}

void OLED_Init(void)
{
    OLED_Write_Command(0xAE);
    OLED_Write_Command(0x20);
    OLED_Write_Command(0x10);
    OLED_Write_Command(0xB0);
    OLED_Write_Command(0xC8);
    OLED_Write_Command(0x00);
    OLED_Write_Command(0x10);
    OLED_Write_Command(0x40);
    OLED_Write_Command(0x81);
    OLED_Write_Command(0x7F);
    OLED_Write_Command(0xA1);
    OLED_Write_Command(0xA6);
    OLED_Write_Command(0xA8);
    OLED_Write_Command(0x3F);
    OLED_Write_Command(0xA4);
    OLED_Write_Command(0xD3);
    OLED_Write_Command(0x00);
    OLED_Write_Command(0xD5);
    OLED_Write_Command(0xF0);
    OLED_Write_Command(0xD9);
    OLED_Write_Command(0x22);
    OLED_Write_Command(0xDA);
    OLED_Write_Command(0x12);
    OLED_Write_Command(0xDB);
    OLED_Write_Command(0x20);
    OLED_Write_Command(0x8D);
    OLED_Write_Command(0x14);
    OLED_Write_Command(0xAF);
}

void OLED_Clear(void)
{
    uint8_t x, y;
    for (y = 0; y < 8; y++)
    {
        OLED_Write_Command((uint8_t) (0xb0 + y));
        OLED_Write_Command(0x00);
        OLED_Write_Command(0x10);
        for (x = 0; x <= X_WIDTH; x++)
        {
            OLED_Write_Data(0);
        }
    }
}

void Display_On(void)
{
    OLED_Write_Command(0xAF);
}

void Display_Off(void)
{
    OLED_Write_Command(0xAE);
}

void OLED_SetCursor(uint8_t x, uint8_t y)
{
    OLED_Write_Command((uint8_t) (0xb0 + y));
    OLED_Write_Command((uint8_t) (((x & 0xf0) >> 4) | 0x10));
    OLED_Write_Command((uint8_t) ((x & 0x0f) | 0x01));
}

void OLED_Put6x8ASCII(uint8_t x, uint8_t y, char ch[])
{
    uint8_t c = 0, i = 0, j = 0;
    while (j < strlen(ch))
    {
        c = (uint8_t) (ch[j] - 0x20);
        if (x > 126)
        {
            x = 0;
            y++;
        }
        OLED_SetCursor(x, y);
        for (i = 0; i < 6; i++)
        {
            OLED_Write_Data(Font6x8[c][i]);
        }
        x += 6;
        j++;
    }
}

void OLED_Put6x8Str(uint8_t x, uint8_t y, char data[])
{
    uint8_t cIndex = 0, i = 0, j = 0;
    while (j < strlen(data))
    {
        cIndex = (uint8_t) (data[j] - 0x20);
        if (x > 126)
        {
            x = 0;
            y++;
        }
        OLED_SetCursor(x, y);
        for (i = 0; i < 6; i++)
        {
            OLED_Write_Data(Font6x8[cIndex][i]);
        }
        x += 6;
        j++;
    }
}

void OLED_Put8x16ASCII(uint8_t x, uint8_t y, char ch[])
{
    uint8_t c = 0, i = 0, j = 0;
    while (j < strlen(ch))
    {
        c = (uint8_t) (ch[j] - 0x20);
        if (x > 120)
        {
            x = 0;
            y++;
        }
        OLED_SetCursor(x, y);
        for (i = 0; i < 8; i++)
        {
            OLED_Write_Data(Font8x16[c][i]);
        }
        OLED_SetCursor(x, (uint8_t) (y + 1));
        for (i = 8; i < 16; i++)
        {
            OLED_Write_Data(Font8x16[c][i]);
        }
        x += 8;
        j++;
    }
}

void OLED_Put8x16Str(uint8_t x, uint8_t y, char data[])
{
    uint8_t cIndex = 0, i = 0, j = 0;
    while (j < strlen(data))
    {
        cIndex = (uint8_t) (data[j] - 0x20);
        if (x > 120)
        {
            x = 0;
            y++;
        }
        OLED_SetCursor(x, y);
        for (i = 0; i < 8; i++)
        {
            OLED_Write_Data(Font8x16[cIndex][i]);
        }
        OLED_SetCursor(x, (uint8_t) (y + 1));
        for (i = 8; i < 16; i++)
        {
            OLED_Write_Data(Font8x16[cIndex][i]);
        }
        x += 8;
        j++;
    }
}