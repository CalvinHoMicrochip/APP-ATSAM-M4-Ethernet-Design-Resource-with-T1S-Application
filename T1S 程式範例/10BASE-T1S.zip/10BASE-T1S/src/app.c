/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/
#include "app.h"
#include <stdlib.h>
#include "definitions.h"
#include "lwip/init.h"
#include "lwip/netif.h"
#include "lwip/timers.h"
#include "tc6.h"
#include "tc6-regs.h"
#include "tc6-lwip.h"
#include "tc6-stub.h"
#include "spi_async_driver.h"
#include "udp_handler.h"
#include "peripheral/port/plib_port.h"
#include "OLED128x64.h"

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                        Global Data Definitions                       */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

#define T1S_PLCA_ENABLE             (true)
#define T1S_PLCA_NODE_ID            (2)
#define T1S_PLCA_NODE_COUNT         (8)
#define T1S_PLCA_BURST_COUNT        (0)
#define T1S_PLCA_BURST_TIMER        (0x80)
#define MAC_PROMISCUOUS_MODE        (false)
#define MAC_TX_CUT_THROUGH          (false)
#define MAC_RX_CUT_THROUGH          (false)
#define PRINT_RATE_TIMEOUT          (1000)
//
#define PRINT(...)                  printf(__VA_ARGS__)
#define ASSERT(x)
#define ESC_RESETCOLOR              "\033[0m"
#define ESC_GREEN                   "\033[0;32m"
#define ESC_RED                     "\033[0;31m"
#define ESC_YELLOW                  "\033[1;33m"
#define ESC_BLUE                    "\033[0;36m"
//
#if Training_Lab == Lab2
#define MCP9800_ADDRESS 0x48
#define MCP9800_REG_TA 0x01
#define MCP9800_Register 0x60
#define MCP9800_Start 0x00
#endif
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                    Application Callback Functions                    */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static bool TC6_IntActive(void);
static void TC6_ReleaseInt(void);
static void TC6IntHandler(uintptr_t context);
static void UdpHandler_CB_OnTransmit(void);
void UdpHandler_CB_OnReceive(uint8_t *buffer, uint16_t len);
#if Training_Lab == Lab1
static void Push_Button(void);
#elif Training_Lab == Lab3
static void CAN_Receive(uint8_t numberOfMessage, CAN_RX_BUFFER *rxBuf, uint8_t rxBufLen);
#endif
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                     Application Local Functions                      */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

extern SYSTICK_OBJECT systick; /* Instanced in plib_systick.c */
static const uint8_t m_ip[] = {192, 168, 0, T1S_PLCA_NODE_ID * 10};
static const uint8_t m_mac[] = {0x00, 0x80, 0xC2, 0x00, 0x01, T1S_PLCA_NODE_ID};

typedef struct
{
    TC6_t *tc6;
    uint8_t intIn;
    uint8_t intOut;
    uint8_t intReported;
    bool last_sw;
} MainLocal_t;

static MainLocal_t m = {0};

uint8_t StringBuffer[100];
#if Training_Lab == Lab1
uint8_t BT_Count = 0;
#elif Training_Lab == Lab2
volatile uint8_t TMR_Flag = 0;
uint16_t ADC_Result;
uint8_t MCP9800_Write_Data[2];
uint8_t MCP9800_Read_Data[2];
#elif Training_Lab == Lab3
uint8_t Can0MessageRAM[CAN0_MESSAGE_RAM_CONFIG_SIZE] __attribute__((aligned(32)));
#define READ_ID(id)  (id >> 18)
static uint8_t CAN_RX[CAN0_RX_FIFO0_SIZE];
uint8_t numberOfMessage = 0;
uint32_t ID = 0;
uint8_t Length = 0;
uint8_t CAN_RX_Data[8];
#endif
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                              MACROS                                  */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

#define PrintRateLimited(idx, timeout, name, value)                                 \
do {                                                                                \
    static uint32_t cnt_ = 0;                                                       \
    static uint32_t t0_;                                                            \
    uint32_t now = systick.tickCounter;                                             \
    if (cnt_ > 0 && (uint32_t)(now - t0_) < (uint32_t)(timeout)) {                  \
        ++cnt_;                                                                     \
    } else {                                                                        \
        t0_ = now;                                                                  \
        if (cnt_ <= 1) {                                                            \
            PRINT("%08lu: %s: 0x%08lX\r\n",                                           \
                    t0_, (name), ((uint32_t)value));                                \
        } else {                                                                    \
            PRINT("%08lu: %s: 0x%08lX [skipped %lu]\r\n",                             \
                    t0_, (name), ((uint32_t)value), cnt_ - 1);                      \
        }                                                                           \
        cnt_ = 1;                                                                   \
    }                                                                               \
} while(0)

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                           CALLBACK SECTION                           */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
#if Training_Lab == Lab2

void TC0_TimerExpired(TC_TIMER_STATUS status, uintptr_t context)
{
    if (status & TC_INTFLAG_OVF_Msk)
        TMR_Flag = 1;
}
#endif
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                         PUBLIC FUNCTIONS                             */

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

void APP_Initialize(void)
{
    printf("\033[2J");
    printf("\033[1;1H");
    printf("\033[?25l");
    printf(">> Initialization Started. \r\n");
    memset(&m, 0, sizeof (m));
    NVIC_Initialize();
    SYSTICK_TimerStart();
    //
#if Training_Lab == Lab2
    TC0_TimerCallbackRegister(TC0_TimerExpired, (uintptr_t) NULL);
    TC0_TimerStart();
    ADC0_Enable();
    MCP9800_Write_Data[0] = MCP9800_REG_TA;
    MCP9800_Write_Data[1] = MCP9800_Register;
    SERCOM1_I2C_Write(MCP9800_ADDRESS, MCP9800_Write_Data, 2);
    while (SERCOM1_I2C_IsBusy());
    MCP9800_Write_Data[0] = MCP9800_Start;
    SERCOM1_I2C_Write(MCP9800_ADDRESS, MCP9800_Write_Data, 1);
    while (SERCOM1_I2C_IsBusy());
#endif
    //
    SYSTICK_DelayMs(200);
    OLED_Init();
    OLED_Clear();
    SYSTICK_DelayMs(200);
    //
    SpiDrvAsync_Init();
    EIC_CallbackRegister(EIC_PIN_0, TC6IntHandler, 0);
    TC6Stub_InitializeSpi(0);
    sprintf((char *) StringBuffer, ">> SAME54N20A");
    OLED_Put6x8Str(0, 0, (char*) StringBuffer);
    sprintf((char *) StringBuffer, ">> NODE ID = %d", T1S_PLCA_NODE_ID);
    OLED_Put6x8Str(0, 2, (char*) StringBuffer);
    printf("%s\r\n", StringBuffer);
    //
    printf(">> NODE COUNT = %d\r\n", T1S_PLCA_NODE_COUNT);
    lwip_init();
    m.tc6 = TC6_Init(NULL);
    if (!m.tc6)
    {
        printf("Failed to initialize TC6 protocol driver\r\n");
        ASSERT(false);
        goto ERROR;
    }
    if (!TC6Regs_Init(m.tc6, &m, m_mac, T1S_PLCA_ENABLE, T1S_PLCA_NODE_ID, T1S_PLCA_NODE_COUNT, T1S_PLCA_BURST_COUNT, T1S_PLCA_BURST_TIMER, MAC_PROMISCUOUS_MODE, MAC_TX_CUT_THROUGH, MAC_RX_CUT_THROUGH))
    {
        printf("Failed to set initial register settings\r\n");
        ASSERT(false);
        goto ERROR;
    }
    while (!TC6Regs_GetInitDone(m.tc6))
    {
        TC6_Service(m.tc6, true);
        TC6Regs_CheckTimers();
    }
    if (!TC6LwIP_Init(m_ip, m_mac, m.tc6))
    {
        printf("Failed to initialize TC6 lwIP Driver\r\n");
    }
    UdpHandler_Init();
    //
#if Training_Lab == Lab3
    CAN0_MessageRAMConfigSet(Can0MessageRAM);
#endif
    //
#if Training_Lab == Lab1
    LED2_Clear();
    LED3_Set();
    LED4_Set();
#elif Training_Lab == Lab2
    LED1_Set();
    LED2_Set();
    LED3_Clear();
    LED4_Set();
#elif Training_Lab == Lab3
    LED1_Set();
    LED2_Set();
    LED3_Set();
    LED4_Clear();
#endif
    //Init device
    printf(">> Initialization Completed. \r\n");
    sprintf((char *) StringBuffer, ">> Transmit Value : ");
    OLED_Put6x8Str(0, 3, (char*) StringBuffer);
    sprintf((char *) StringBuffer, ">> Receive Value : ");
    OLED_Put6x8Str(0, 5, (char*) StringBuffer);
    return;
ERROR:
    while (true);
}

void APP_Tasks(void)
{
    sys_check_timeouts();
    SpiDrvAsync_Service();
    TC6Regs_CheckTimers();
    if (TC6_IntActive())
    {
        if (TC6_Service(m.tc6, false))
        {
            TC6_ReleaseInt();
        }
    }
    else
    {
        TC6_Service(m.tc6, true);
    }
#if Training_Lab == Lab1
    Push_Button();
#elif Training_Lab == Lab2
    if (TMR_Flag)
    {
        TMR_Flag = 0;
        //
        SERCOM1_I2C_Read(MCP9800_ADDRESS, MCP9800_Read_Data, 2);
        while (SERCOM1_I2C_IsBusy());
        //
        ADC0_ConversionStart();
        while (!ADC0_ConversionStatusGet());
        ADC_Result = ADC0_ConversionResultGet();
        UdpHandler_CB_OnTransmit();
    }
#elif Training_Lab == Lab3
    numberOfMessage = CAN0_RxFifoFillLevelGet(CAN_RX_FIFO_0);
    if (numberOfMessage != 0)
    {
        memset(CAN_RX, 0x00, (numberOfMessage * CAN0_RX_FIFO0_ELEMENT_SIZE));
        if (CAN0_MessageReceiveFifo(CAN_RX_FIFO_0, numberOfMessage, (CAN_RX_BUFFER *) CAN_RX) == true)
        {
            CAN_Receive(numberOfMessage, (CAN_RX_BUFFER *) CAN_RX, CAN0_RX_FIFO0_ELEMENT_SIZE);
        }
    }
#endif
}

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                          USER FUNCTIONS                              */

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
static void UdpHandler_CB_OnTransmit(void)
{
#if Training_Lab == Lab1
    uint8_t txBuffer[4];
    /* Create the UDP payload. */
    *(uint16_t*) txBuffer = SWITCH_VALUE;
    txBuffer[2] = T1S_PLCA_NODE_ID;
    txBuffer[3] = BT_Count;
    sprintf((char *) StringBuffer, ">> 0x%02X.0x%02X.0x%02X", (txBuffer[0] | txBuffer[1] << 8), txBuffer[2], txBuffer[3]);
    OLED_Put6x8Str(0, 4, (char*) StringBuffer);
    /* Send click information through UDP. */
    if (UdpHandler_Send(txBuffer, 4) == 0)
    {

    }
#elif Training_Lab == Lab2
    uint8_t txBuffer[6];
    /* Create the UDP payload. */
    *(uint16_t*) txBuffer = SWITCH_VALUE;
    txBuffer[2] = (ADC_Result >> 8);
    txBuffer[3] = ADC_Result;
    txBuffer[4] = MCP9800_Read_Data[0];
    txBuffer[5] = MCP9800_Read_Data[1];
    sprintf((char *) StringBuffer, ">>VR:%4d,Temp:%2d.%3d", ADC_Result, (int) (MCP9800_Read_Data[0]&0x7F), (int) ((MCP9800_Read_Data[1] >> 4)*1000 / 16));
    OLED_Put6x8Str(0, 4, (char*) StringBuffer);
    /* Send click information through UDP. */
    if (UdpHandler_Send(txBuffer, 6) == 0)
    {

    }
#elif Training_Lab == Lab3
    uint8_t txBuffer[13];
    /* Create the UDP payload. */
    *(uint16_t*) txBuffer = SWITCH_VALUE;
    txBuffer[2] = ID;
    txBuffer[3] = (ID >> 8);
    txBuffer[4] = Length;
    for (uint8_t loop = 0; loop < Length; loop++)
    {
        txBuffer[5 + loop] = CAN_RX_Data[loop];
    }
    sprintf((char *) StringBuffer, ">> View Tera Term");
    OLED_Put6x8Str(0, 4, (char*) StringBuffer);
    /* Send click information through UDP. */
    if (UdpHandler_Send(txBuffer, (5 + Length)) == 0)
    {

    }
#endif
}

void UdpHandler_CB_OnReceive(uint8_t *buffer, uint16_t len)
{
    char my[len];
    memset(my, '\0', sizeof (my));
    for (int i = 0; i < len; i++)
    {
        my[i] = buffer[i];
    }
#if Training_Lab == Lab1
    sprintf((char *) StringBuffer, ">> 0x%02X.0x%02X.0x%02X", (my[0] | my[1] << 8), my[2], my[3]);
#elif Training_Lab == Lab2
    sprintf((char *) StringBuffer, ">>VR:%4d,Temp:%2d.%3d", (my[2] << 8 | my[3]), (int) (my[4]&0x7F), (int) ((my[5] >> 4)*1000 / 16));
#elif Training_Lab == Lab3
    sprintf((char *) StringBuffer, ">> 0x%02X.0x%02X.0x%02X", (my[0] | my[1] << 8), (my[2] | my[3] << 8), my[4]);
#endif
    OLED_Put6x8Str(0, 6, (char*) StringBuffer);
}
#if Training_Lab == Lab1

static void Push_Button(void)
{
    bool sw;
    sw = SW1_Get();
    if (sw != m.last_sw)
    {
        m.last_sw = sw;
        if (!sw)
        {
            BT_Count++;
            LED1_Toggle();
            UdpHandler_CB_OnTransmit();
        }
    }
}
#elif Training_Lab == Lab3

static void CAN_Receive(uint8_t numberOfMessage, CAN_RX_BUFFER *rxBuf, uint8_t rxBufLen)
{
    for (uint8_t count = 0; count < numberOfMessage; count++)
    {
        ID = rxBuf->xtd ? rxBuf->id : READ_ID(rxBuf->id);
        Length = rxBuf->dlc;
        printf("CAN ID : 0x%x Length : 0x%x ", (unsigned int) ID, (unsigned int) Length);
        printf("DATA : ");
        for (uint8_t loop = 0; loop < Length; loop++)
        {
            CAN_RX_Data[loop] = rxBuf->data[loop];
            printf("0x%X ", CAN_RX_Data[loop]);
        }
        printf("\r\n");
    }
    UdpHandler_CB_OnTransmit();
}
#endif
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                         PUBLIC FUNCTIONS                             */

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static bool TC6_IntActive(void)
{
    m.intReported = m.intIn;
    return (m.intReported != m.intOut);
}

static void TC6_ReleaseInt(void)
{
    if (TC6_INT_Get())
    {
        m.intOut = m.intReported;
    }
}

static void TC6IntHandler(uintptr_t context)
{
    m.intIn++;
}

u32_t sys_now(void)
{
    return systick.tickCounter;
}

void TC6_CB_OnNeedService(TC6_t *pInst, void *pGlobalTag)
{

}

void TC6_CB_OnInternalLoop()
{
    SpiDrvAsync_Service();
}

void TC6_CB_OnError(TC6_t *pInst, TC6_Error_t err, void *pGlobalTag)
{
    bool reinit = false;
    switch (err)
    {
    case TC6Error_Succeeded: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "No error occurred", 0);
        break;
    case TC6Error_NoHardware: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "MISO data implies that there is no MACPHY hardware available", 0);
        break;
    case TC6Error_UnexpectedSv: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "Unexpected Start Valid Flag", 0);
        break;
    case TC6Error_UnexpectedDvEv: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "Unexpected Data Valid or End Valid Flag", 0);
        break;
    case TC6Error_BadChecksum: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "Checksum in footer is wrong", 0);
        break;
    case TC6Error_UnexpectedCtrl: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "Unexpected control packet received", 0);
        break;
    case TC6Error_BadTxData: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "Header Bad Flag received", 0);
        break;
    case TC6Error_SyncLost: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "Sync Flag is no longer set", 0);
        reinit = true;
        break;
    default: PrintRateLimited(0, PRINT_RATE_TIMEOUT, "Unknown TC6 error occurred", 0);
        break;
    }
    if (reinit)
    {
        TC6Regs_Reinit(pInst);
    }
}

void TC6Regs_CB_OnEvent(TC6_t *pInst, TC6Regs_Event_t event, void *pTag)
{
    bool reinit = false;
    switch (event)
    {
    case TC6Regs_Event_UnknownError:
        PRINT(ESC_RED "UnknownError" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Transmit_Protocol_Error:
        PRINT(ESC_RED "Transmit_Protocol_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Transmit_Buffer_Overflow_Error:
        PRINT(ESC_RED "Transmit_Buffer_Overflow_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Transmit_Buffer_Underflow_Error:
        PRINT(ESC_RED "Transmit_Buffer_Underflow_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Receive_Buffer_Overflow_Error:
        PRINT(ESC_RED "Receive_Buffer_Overflow_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Loss_of_Framing_Error:
        PRINT(ESC_RED "Loss_of_Framing_Error" ESC_RESETCOLOR "\r\n");
        reinit = true;
        break;
    case TC6Regs_Event_Header_Error:
        PRINT(ESC_RED "Header_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Reset_Complete:
        PRINT(ESC_GREEN "Reset_Complete" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_PHY_Interrupt:
        PRINT(ESC_GREEN "PHY_Interrupt" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Transmit_Timestamp_Capture_Available_A:
        PRINT(ESC_GREEN "Transmit_Timestamp_Capture_Available_A" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Transmit_Timestamp_Capture_Available_B:
        PRINT(ESC_GREEN "Transmit_Timestamp_Capture_Available_B" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Transmit_Timestamp_Capture_Available_C:
        PRINT(ESC_GREEN "Transmit_Timestamp_Capture_Available_C" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Transmit_Frame_Check_Sequence_Error:
        PRINT(ESC_RED "Transmit_Frame_Check_Sequence_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Control_Data_Protection_Error:
        PRINT(ESC_RED "Control_Data_Protection_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_RX_Non_Recoverable_Error:
        PRINT(ESC_RED "RX_Non_Recoverable_Error" ESC_RESETCOLOR "\r\n");
        reinit = true;
        break;
    case TC6Regs_Event_TX_Non_Recoverable_Error:
        PRINT(ESC_RED "TX_Non_Recoverable_Error" ESC_RESETCOLOR "\r\n");
        reinit = true;
        break;
    case TC6Regs_Event_FSM_State_Error:
        PRINT(ESC_RED "FSM_State_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_SRAM_ECC_Error:
        PRINT(ESC_RED "SRAM_ECC_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Undervoltage:
        PRINT(ESC_RED "Undervoltage" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Internal_Bus_Error:
        PRINT(ESC_RED "Internal_Bus_Error" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_TX_Timestamp_Capture_Overflow_A:
        PRINT(ESC_RED "TX_Timestamp_Capture_Overflow_A" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_TX_Timestamp_Capture_Overflow_B:
        PRINT(ESC_RED "TX_Timestamp_Capture_Overflow_B" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_TX_Timestamp_Capture_Overflow_C:
        PRINT(ESC_RED "TX_Timestamp_Capture_Overflow_C" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_TX_Timestamp_Capture_Missed_A:
        PRINT(ESC_RED "TX_Timestamp_Capture_Missed_A" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_TX_Timestamp_Capture_Missed_B:
        PRINT(ESC_RED "TX_Timestamp_Capture_Missed_B" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_TX_Timestamp_Capture_Missed_C:
        PRINT(ESC_RED "TX_Timestamp_Capture_Missed_C" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_MCLK_GEN_Status:
        PRINT(ESC_YELLOW "MCLK_GEN_Status" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_gPTP_PA_TS_EG_Status:
        PRINT(ESC_YELLOW "gPTP_PA_TS_EG_Status" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Extended_Block_Status:
        PRINT(ESC_YELLOW "Extended_Block_Status" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_SPI_Err_Int:
        PRINT(ESC_YELLOW "SPI_Err_Int" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_MAC_BMGR_Int:
        PRINT(ESC_YELLOW "MAC_BMGR_Int" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_MAC_Int:
        PRINT(ESC_YELLOW "MAC_Int" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_HMX_Int:
        PRINT(ESC_YELLOW "HMX_Int" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_GINT_Mask:
        PRINT(ESC_YELLOW "GINT_Mask" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Chip_Error:
        PRINT(ESC_RED "Chip_error! Please contact microchip support for replacement" ESC_RESETCOLOR "\r\n");
        break;
    case TC6Regs_Event_Unsupported_Hardware:
        PRINT(ESC_RED "Unsupported MAC-PHY hardware found" ESC_RESETCOLOR "\r\n");
        break;
    }
    if (reinit)
    {
        TC6Regs_Reinit(pInst);
    }
}

bool TC6LwIP_CB_OnRxEthernetPacket(struct pbuf *pRx, uint16_t ethType)
{
    const char *str = "unknown";
    bool tcpStack = false;
    bool hide = false;
    ASSERT(pRx);
    switch (ethType)
    {
    case 0x0800:
        str = "IPv4";
        if (pRx->len >= 17 && 0x1 == ((uint8_t *) pRx->payload)[0x17])
        {
            str = "Ping";
            hide = true;
        }
        else
        {
            hide = true;
        }
        tcpStack = true;
        break;
    case 0x0806:
        str = "ARP";
        tcpStack = true;
        break;
    case 0x22F0:
        str = "AVTP";
        break;
    case 0x8100:
        str = "VLAN";
        break;
    case 0x86DD:
        str = "IPv6";
    case 0x88F7:
        str = "PTPv2";
        break;
    }
    if (!hide)
    {
        printf("%08lu:Received Ethernet frame with Type=0x%04X (%s), lwIP=%s\r\n", systick.tickCounter, ethType, str, (tcpStack ? "process" : "ignore"));
    }
    return tcpStack;
}
